function [Population] = Response3(PROBLEM,Population,i,clusterDirction,Center,objRank,option)
    tmpDist = pdist2(objRank(i,:),Center);
    [~,mindistIndex] = min(tmpDist);
    switch option
        case 1              
            individual = Population(i).dec + clusterDirction(mindistIndex,:);
            individual = min(max(individual,PROBLEM.lower),PROBLEM.upper);
        case 2
            sigma = clusterDirction(mindistIndex,:)./10;
            individual = Population(i).dec + clusterDirction(mindistIndex,:) + normrnd(clusterDirction(mindistIndex,:),sigma);
            individual = min(max(individual,PROBLEM.lower),PROBLEM.upper);
    end
    x = PROBLEM.Evaluation(individual);
    Population(i) = x;
end
