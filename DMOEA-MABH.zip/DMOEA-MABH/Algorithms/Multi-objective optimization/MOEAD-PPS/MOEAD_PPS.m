classdef MOEAD_PPS < ALGORITHM
%<multi/many> <real> <none> <dynamic>
    methods
        function main(Algorithm,Problem)
            t = 1;
            Problem.iter = t;
            Population = Problem.Initialization();
            AllPop = [];
            %% Parameter setting
            type = Algorithm.ParameterSet(2);

            %% Generate the weight vectors
            [W,~] = UniformPoint(Problem.N,Problem.M);
            W=Update_Weight(W,Problem.N);
            T = ceil(Problem.N/5);

            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);

            %% Generate random population
            Z = min(Population.objs,[],1);
            %%
            changeTag = 0;
            while Algorithm.NotTerminated(Population)
                if Changed(Problem,Population)
                    AllPop = [AllPop,Population];
                    if changeTag == 0
                        Population = initialRection(Problem,Population);
                        changeTag = 1;
                        Ct_1 = mean(Population.decs,1);
                    else
                        [Population,Ct_1] = ChangeRection(Problem,Population,Ct_1);
                    end
                    Population=Vector_matching(Population,W);
                end
                % For each solution
                for i = 1 : Problem.N
                    % Choose the parents
                    P = B(i,randperm(size(B,2)));

                    % Generate an offspring
                    Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});

                    % Update the ideal point
                    Z = min(Z,Offspring.obj);
                    g_old = max(abs(Population(P).objs-repmat(Z,T,1)).*W(P,:),[],2);
                    g_new = max(repmat(abs(Offspring.obj-Z),T,1).*W(P,:),[],2);
                    update_index=P(find(g_old>=g_new,type));
                    Population(update_index) = Offspring;
                end
                for ii = 1 : length(Population)
                    Population(ii).iter = t;
                end
                if Problem.iter >= Problem.maxIter - 1
                    Population = [AllPop,Population];
                end
                t = t + 1;
                Problem.iter = t;
            end
        end
    end


end