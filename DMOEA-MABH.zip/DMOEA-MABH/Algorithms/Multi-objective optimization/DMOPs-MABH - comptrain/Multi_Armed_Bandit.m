function [Population,totalReward,numPlays,armRecord] = Multi_Armed_Bandit(Problem,Population,responsePrar,randChoseResult,numPlays,historyReward,trainGroup,Memory_Set,diversityIncrease)
    criticPoint = Memory_Set(:,1);
    t_size = size(Memory_Set,2);
    valCriticPoint = Problem.Evaluation(criticPoint.decs);
    [FrontNoOfMemory,~] = NDSort(valCriticPoint.objs,length(valCriticPoint));
    [~,sortFrontNoOfMemory] = sort(FrontNoOfMemory);
    FrontNoOfMemoryRank = sort(sortFrontNoOfMemory);
    Memory_Set = Memory_Set(FrontNoOfMemoryRank,:);
    Memory_Set = reshape(Memory_Set,[],1).';
    sumFrontNoOfMemory=sum(FrontNoOfMemory(FrontNoOfMemory==1));
    if sumFrontNoOfMemory>1
        Memory_Set(1:sumFrontNoOfMemory*t_size)=Memory_Set(randperm(sumFrontNoOfMemory*t_size));
    end
    numArms=responsePrar.numArms;
    % 多臂赌博机的臂数numArms
    % ε贪心算法
    numIterations = length(trainGroup);armRecord = zeros(1,numIterations);
    % 初始化每个臂的总奖励和选择次数
    totalReward = historyReward;
    %numPlays = zeros(1, numArms);
    % 模拟numIterations次选择
    % 开始模拟选择过程
    for i = 1 : numArms
        [Population,reward,Memory_Set,randChoseResult] = playArm(i,Problem,Population,i,randChoseResult,responsePrar,trainGroup,Memory_Set,diversityIncrease);
        reward = i./numIterations * reward;
        numPlays(i) = numPlays(i) + 1;
        totalReward(i) = totalReward(i) + 0.1*(reward-totalReward(i));
        armRecord(i) = i;
    end

    for i =  1:numIterations
        % 使用ε-贪心算法选择一个臂
        if rand() < 0
            % 随机选择一个臂进行探索
            chosenArm = randi(numArms);
        else
            % 选择估计收益最高的臂进行利用
            estimatedMeans = totalReward ./ numPlays;
            estimatedMeans(isnan(estimatedMeans)) = 0;
            a = cumsum(estimatedMeans)./sum(estimatedMeans);
            b = rand(1);
            if b < a(1)
                chosenArm = 1;
            elseif b>=a(1) && b<=a(2)
                chosenArm = 2;
            else
                chosenArm = 3;
            end

            %[~, chosenArm] = max(estimatedMeans);
            %chosenArm = 3;
        end
        % 假设根据选择的臂执行并得到奖励
        %chosenArm = 2;
        [Population,reward,Memory_Set,randChoseResult] = playArm(chosenArm,Problem,Population,i,randChoseResult,responsePrar,trainGroup,Memory_Set,diversityIncrease);
        reward = i./numIterations * reward;
        % 更新选择的臂的总奖励和选择次数
        numPlays(chosenArm) = numPlays(chosenArm) + 1;%1;
        totalReward(chosenArm) = totalReward(chosenArm) + 0.1*(reward-totalReward(chosenArm));%(reward - totalReward(chosenArm)) / numPlays(chosenArm);
        armRecord(i) = chosenArm;
    end
end