function [Population] = Response1(PROBLEM,Population,i,C_Dirction,option)
    switch option
        case 1
            individual = Population(i).dec + C_Dirction;
            individual = min(max(individual,PROBLEM.lower),PROBLEM.upper);
        case 2
            sigma = C_Dirction./10;
            individual = Population(i).dec + C_Dirction + normrnd(0,sigma);
            individual = min(max(individual,PROBLEM.lower),PROBLEM.upper);
    end
    x = PROBLEM.Evaluation(individual);
    Population(i) = x;
end

