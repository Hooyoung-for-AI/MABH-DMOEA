function Population = initialRection(Problem,Population)
    for i = 1 : Problem.N
        if rand < 0.5
            Population(i) = Problem.Evaluation(Population(i).dec);
        else
            Population(i) = Problem.Evaluation(Problem.lower + rand(1,Problem.D) .* (Problem.upper-Problem.lower));
        end
    end
end