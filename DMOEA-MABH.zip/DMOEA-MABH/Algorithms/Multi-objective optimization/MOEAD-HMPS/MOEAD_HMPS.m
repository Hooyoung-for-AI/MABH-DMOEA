classdef MOEAD_HMPS < ALGORITHM
%<multi/many> <real> <none> <dynamic>
    methods
        function main(Algorithm,Problem)
            t = 1;
            Problem.iter = t;
            epsilon = 0.0001;
            archiveSize = 50;
            D = [];
            C = [];
            flag = 0;
            index = -1;
            Population = Problem.Initialization();
            detecterIndex = randi(100,10,1);
            timeStep = 0;
            AllPop = [];
            %% Parameter setting
            type = Algorithm.ParameterSet(2);

            %% Generate the weight vectors
            [W,~] = UniformPoint(Problem.N,Problem.M);
            W=Update_Weight(W,Problem.N);
            T = ceil(Problem.N/5);

            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);

            %% Generate random population
            Z = min(Population.objs,[],1);
            %%
            changeTag = 0;
            tchval = zeros(1,Problem.N);
            while Algorithm.NotTerminated(Population)
                detecter = Population(detecterIndex);
                [change,detecter] = ChangeDetect(Problem,detecter);
                if change
                    [~,Rank] = sort(tchval);
                    AllPop = [AllPop,Population];
                    F = mean(detecter.objs,1); 
                    if changeTag == 0
                        Population = initialRection(Problem,Population,Rank);
                        [D,C] = MemoryStrategy(Population,D,C,archiveSize,flag,index,F);
                        changeTag = 1;
                        Ct_1 = mean(Population.decs,1);
                    else
                        [flag,index] = isSimilar(Problem,D,F,epsilon);
                        [D,C] = MemoryStrategy(Population,D,C,archiveSize,flag,index,F);
                        [Population,Ct_1] = ChangeRection(Problem,flag,index,C,Population,Rank,Ct_1);
                    end
                    timeStep = timeStep + 1;
                    Population=Vector_matching(Population,W);
                end
                % For each solution
                for i = 1 : Problem.N
                    % Choose the parents
                    P = B(i,randperm(size(B,2)));

                    % Generate an offspring
                    Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});

                    % Update the ideal point
                    Z = min(Z,Offspring.obj);
                    g_old = max(abs(Population(P).objs-repmat(Z,T,1)).*W(P,:),[],2);
                    g_new = max(repmat(abs(Offspring.obj-Z),T,1).*W(P,:),[],2);
                    update_index=P(find(g_old>=g_new,type));
                    Population(update_index) = Offspring;
                end
                tchval = max(abs(Population.objs-repmat(Z,Problem.N,1)).*W,[],2);
                


                for ii = 1 : length(Population)
                    Population(ii).iter = t;
                end
                if Problem.iter >= Problem.maxIter - 1
                    Population = [AllPop,Population];
                end
                t = t + 1;
                Problem.iter = t;
            end
        end
    end


end