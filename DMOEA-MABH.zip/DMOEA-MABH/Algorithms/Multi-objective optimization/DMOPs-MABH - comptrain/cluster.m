function [clusterRepresentIdv,clusterRepresentObjRank,clusterRepresentDec] = cluster(Problem,Population,FrontNo)
    [idx] = kmeans(Population.objs,20);
    clusterTmpIndex = cell(1,20);
    for i = 1 : 20
        %得到每个类中个体的索引
        clusterTmpIndex(i) = {find(idx == i)};
    end
    clusterRepresentIdv = zeros(1,20);
    for i = 1 : 20
        clusterIdv = cell2mat(clusterTmpIndex(i));
        chackFrontNo = FrontNo(clusterIdv);
        [~,minFrontNo] = min(chackFrontNo);
        clusterRepresentIdv(i) = clusterIdv(minFrontNo);
    end
    clusterReprsentPop = Population(clusterRepresentIdv);
    %clusterRepresentObj = clusterReprsentPop.objs;
    clusterRepresentDec = clusterReprsentPop.decs;
    rank = zeros(Problem.N,Problem.M);
    PopulationObj = Population.objs;
    for i = 1 : Problem.M
        [~,index] = sort(PopulationObj(:,i));
        [~,rank(:,i)] = sort(index);
    end
    clusterRepresentObjRank = rank(clusterRepresentIdv,:);
end