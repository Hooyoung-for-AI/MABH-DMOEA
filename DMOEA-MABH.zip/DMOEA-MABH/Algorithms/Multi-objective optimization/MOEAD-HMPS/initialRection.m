function Population = initialRection(Problem,Population,Rank)
    for i = 1 : Problem.N
        if Rank <= 50
            Population(i) = Problem.Evaluation(Population(i).dec);
        else
            Population(i) = Problem.Evaluation(Problem.lower + rand(1,Problem.D) .* (Problem.upper-Problem.lower));
        end
    end
end