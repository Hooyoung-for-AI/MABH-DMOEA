function [flag,index] = isSimilar(Problem,D,F,epsilon)
    for i = 1 : size(D,1)
        Count = 0;
        for j = 1 : Problem.M
            if abs(D(i,j) - F(j)) < epsilon
                Count = Count + 1;
            end
        end
        if Count == Problem.M
            flag = 1;
            index = i;
            break
        end
        flag = 0;
        index = -1;
    end

end