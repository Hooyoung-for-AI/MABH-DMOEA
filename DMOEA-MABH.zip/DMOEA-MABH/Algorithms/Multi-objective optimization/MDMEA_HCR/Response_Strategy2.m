%% Memory solution introduction strategy
function [New_Pop2,N2]=Response_Strategy2(Problem,Memory_Set,N,D,Lower,Upper)
     New_Pop2_decs=[];
     [FrontNo,~] = NDSort(Memory_Set.objs,Memory_Set.cons,N);
     Memory_Non_domin_indexs=find(FrontNo==1);
     temp_pop=Memory_Set(Memory_Non_domin_indexs);
     num1=length(Memory_Non_domin_indexs);
     if num1>floor(N*0.6)
        Del = Truncation(temp_pop.objs,num1-floor(N*0.6));
         temp_pop=temp_pop(~Del);
         num1=length(temp_pop);    
     end
       New_Pop2_decs=[New_Pop2_decs;temp_pop.decs];
       Random_initialization_decs=Lower.*ones(N-num1,D)+rand(N-num1,D).*(Upper.*ones(N-num1,D)-Lower.*ones(N-num1,D)); 
       New_Pop2_decs=[New_Pop2_decs;Random_initialization_decs];
       New_Pop2=Problem.Evaluation(New_Pop2_decs);
       N2=length(New_Pop2);
end


