function [Population,Ct_1] = ChangeRection(Problem,flag,index,C,Population,Rank,Ct_1)
    Ct = mean(Population.decs,1);
    newPopDec = zeros(Problem.N,Problem.D);
    for i = 1 : Problem.N
        if Rank(i) <= 50
            if flag == 1
                newPopDec(i,:) = Population(i).dec + C(index,:) - Ct;
            else
                sigma = pdist2(Ct,C(end-1,:))./Problem.N;
                newPopDec(i,:) = Population(i).dec + Ct - Ct_1 + normrnd(0,sigma);
            end
        else
            if rand < 0.5
                newPopDec(i,:) = Problem.lower + rand(1,Problem.D) .* (Problem.upper-Problem.lower);
            else
                newPopDec(i,:) = Population(i).dec;
            end
        end
    end
    Population = Problem.Evaluation(newPopDec);
    Ct_1 = Ct;
end
