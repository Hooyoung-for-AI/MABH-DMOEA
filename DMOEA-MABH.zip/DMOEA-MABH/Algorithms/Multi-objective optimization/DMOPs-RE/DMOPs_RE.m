classdef DMOPs_RE < ALGORITHM
%<multi/many> <real> <none> <dynamic>
%基于强化学习的动态多目标算法
%platemo('algorithm',@DMOPs_RE,'problem',@FDA1,'N',100,'maxFE',10000)
    methods
        function main(Algorithm,Problem)
            t = 1;
            Problem.iter = t;
            Population = Problem.Initialization();
            changeTag = 0;
            responsePrar.responseNum = 3;
            historyReward = zeros(1,responsePrar.responseNum);
            AllPop = [];
            numArms = responsePrar.responseNum;
            numPlays = zeros(1, numArms);
 %%
            [FrontNo,~] = NDSort(Population.objs,Problem.N);

 %%
            type = Algorithm.ParameterSet(2);
            T_min=5;T_max=40; Mid_num=floor(Problem.taut/2); r=1;flexible=4;
            Memory_Set=[];K=0; t_size=20;M_num=5;
            dif=0;
%             if Problem.M==2
%                   [W,~] = UniformPoint(Problem.N-9,Problem.M);
%                   W=Update_Weight(W,Problem.N);
%             else
                  [W,~] = UniformPoint(Problem.N-8,Problem.M);
                   W=Update_Weight(W,Problem.N);
%             end  
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            Z = min(Population.objs,[],1);
            changeSeverityRecord = [];
            MutationSelectIndex = 0;
 %%
            %uniformProb = ones(1,responseNum) ./ responseNum;
            while Algorithm.NotTerminated(Population)
                %%
                Tag1=Problem.FE;
                %%
                [changed,RePop,diversityIncrease,changeSeverityRecord] = Changed1(Problem,Population,changeSeverityRecord,changeTag);
                if changed
                    AllPop = [AllPop,Population]; 
                    %%
                    dif=0;
                    [Memory_Set,K]=Memory_store(Population,Memory_Set,t_size,M_num,K,Problem); 
                    %%
                    if changeTag == 0
                        responsePrar.Curr_C = mean(Population.decs,1);
                        [responsePrar.clusterRepresentIdv,responsePrar.clusterRepresentObjRank,responsePrar.clusterRepresentDec] = cluster(Problem,Population,FrontNo);
                        [responsePrar.kneePoint,responsePrar.kneePointIndex] = getKneePoint(Problem,Population,FrontNo);
                        %[MDPC,MDPCdec] = MDPcluster(Problem,Population,kneePointIndex,Problem.M+1);                        
                        for i = 1 : Problem.N
                            Population = Response4(Problem,Population,i);
                        end
                        changeTag = changeTag + 1;
                    else
                        %%
                        responsePrar.Last_C = responsePrar.Curr_C;
                        responsePrar.Curr_C = mean(Population.decs,1);
                        responsePrar.C_Dirction = responsePrar.Curr_C - responsePrar.Last_C;
                        %%
                        responsePrar.oldClusterRepresentIdv = responsePrar.clusterRepresentIdv; responsePrar.oldClusterRepresentObjRank = responsePrar.clusterRepresentObjRank;
                        responsePrar.oldClusterRepresentDec = responsePrar.clusterRepresentDec;
                        [responsePrar.clusterReprsentIdv,responsePrar.clusterRepresentObjRank,responsePrar.clusterRepresentDec] = cluster(Problem,Population,FrontNo);
                        dist_newClusterRepresentObj_oldClusterRepresentObj = pdist2(responsePrar.clusterRepresentObjRank,responsePrar.oldClusterRepresentObjRank);
                        [~,matchRepresentIdvTmp] = min(dist_newClusterRepresentObj_oldClusterRepresentObj,[],2);
                        responsePrar.clusterDirction = responsePrar.clusterRepresentDec - responsePrar.oldClusterRepresentDec(matchRepresentIdvTmp,:);
                        %%
                        responsePrar.oldKneePoint = responsePrar.kneePoint;
                        [responsePrar.kneePoint,responsePrar.kneePointIndex] = getKneePoint(Problem,Population,FrontNo);
                        responsePrar.kneeDirction = responsePrar.C_Dirction;%responsePrar.kneePoint.dec - responsePrar.oldKneePoint.dec;
                        %%
%                         responsePrar.oldMDPCdec = responsePrar.MDPCdec;
%                         [responsePrar.MDPC,responsePrar.MDPCdec] = MDPcluster(Problem,Population,responsePrar.kneePointIndex,Problem.M+1);
%                         responsePrar.MDPDirection = responsePrar.MDPCdec - responsePrar.oldMDPCdec;
%                         

                        %%
%                         randIndex = randi(Problem.N,1,floor(Problem.N ./ 10));
%                         randChosepop = Population(randIndex);
%%
                        NonDonminateSolution = Population(FrontNo == 1);
                        NonDonminateSolutionObjs = NonDonminateSolution.objs;
                        index = zeros(size(NonDonminateSolutionObjs,1),Problem.M);
                        for i = 1 : Problem.M
                            [~,index(:,i)] = sort(NonDonminateSolutionObjs(:,i));
                        end
                        extremeNonDonminateSolution = NonDonminateSolution(index(1,:));
                        extremeNonDonminateSolution = [extremeNonDonminateSolution,responsePrar.kneePoint];
%%
                        [randChoseResult,Memory_Set,numPlays,historyReward] = UniformChangeResponse(Problem,Population,extremeNonDonminateSolution,RePop,numPlays,historyReward,responsePrar,Memory_Set);                 
                        [Population,historyReward,numPlays] = ChangeResponseWithTrain(Problem,Population,randChoseResult,numPlays,historyReward,responsePrar,Memory_Set,diversityIncrease);
                        Population=Vector_matching(Population,W);
                        Z=min(Population.objs,[],1);
                        MutationSelectIndex = 0;
                    end
                    %[~,FrontNo,CrowdDis]   = EnvironmentalSelection(Population,length(Population));
                end
                %else
                    %%
                    Tag2=Problem.FE;
                    if(Tag2-Tag1>100)
                        dif=Tag2-Tag1-100;
                    end
         
%                     if Problem.iter-50>=Problem.taut 
%                         T=T_min+ceil((T_max-T_min)/(exp(-flexible*(r-Mid_num)/Mid_num)+1)); 
%                         B1 = B(:,1:T);
%                     else
                    if Problem.M>2
                        T=50; 
                        B1 = B(:,1:T);
                    else
                        T=30; 
                        B1 = B(:,1:T);
                    end
%                     end  
                        %%
                    for i = 1 : Problem.N
                        if(dif>0)
                            dif=dif-1; continue;
                        end
                        P = B1(i,randperm(end));
                        % Multi-Strategy evolutionary operators based on variable domains
%                         if   T<=T_min+floor((T_max-T_min)/2)
%                             Offspring=DE_current_to_lbest(Problem,Population,Population(i),W,Z,P,Problem.lower,Problem.upper);
%                             Offspring=OperatorGAhalf(Problem,[Population(i) Population(P(1))]);
%                             Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});
%                         else

                        if MutationSelectIndex <= 3

                            tmprand = rand;
                              if tmprand < 0.2
                                  Offspring=OperatorGAhalf(Problem,[Population(i) Population(P(1))]);
                              elseif tmprand <=1
                                  Offspring=DE_current_to_lbest(Problem,Population,Population(i),W,Z,P,Problem.lower,Problem.upper);
                                          %Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});
                              else
                                    Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});
                              end
                        else
                            tmprand = rand;
                              if tmprand <0.5
                                  Offspring=OperatorGAhalf(Problem,[Population(i) Population(P(1))]);
                              elseif tmprand <=0.8
                                  Offspring=DE_current_to_lbest(Problem,Population,Population(i),W,Z,P,Problem.lower,Problem.upper);
                                          %Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});
                              else
                                    Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.5,1,20});
                              end
                         end
                        MutationSelectIndex = MutationSelectIndex + 1;  
                        % Update the ideal point
                        Z = min(Z,Offspring.obj);
                        % Update the solutions in P by Tchebycheff approach
                        g_old = max(abs(Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
                        g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
                        update_index=P(find(g_old>=g_new,type));
                        Population(update_index) = Offspring;
                    end
                %end
                    %%
        %% 选择合适的多目标优化器进行优化
%                     MatingPool = TournamentSelection(2,Problem.N,FrontNo,-CrowdDis);
%                     Offspring  = OperatorGA(Problem,Population(MatingPool));
                [FrontNo,~] = NDSort(Population.objs,Problem.N);                
                %end
                    %%
                for ii = 1 : length(Population)
                    Population(ii).iter = t;
                end
                if Problem.iter >= Problem.maxIter - 1
                    Population = [AllPop,Population];
                end
                r= r+1;
                t = t + 1;
                Problem.iter = t;
                        
            end
        end
    end
end


