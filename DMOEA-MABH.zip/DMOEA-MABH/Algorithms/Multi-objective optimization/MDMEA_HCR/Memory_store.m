%%  Memory storage strategy
function [Memory_Set,K]=Memory_store(Population,Memory_Set,t_size,M_num,K)
       indexs=Farthest_first_selection(Population,t_size);
      if size(Memory_Set,1)<M_num
             Memory_Set=[Memory_Set;Population(indexs)];
      else
            V=mod(K,5)+1;
            Memory_Set(V,:)=Population(indexs);
            K=K+1;
      end
end

