function [Population,Ct_1] = ChangeRection(Problem,Population,Ct_1)
    Ct = mean(Population.decs,1);
    newPopDec = zeros(Problem.N,Problem.D);
    for i = 1 : Problem.N
        if rand < 0.5
                sigma = pdist2(Ct,Ct_1)./Problem.N;
                newPopDec(i,:) = Population(i).dec + Ct - Ct_1 + normrnd(0,sigma);
        else
            if rand < 0.5
                newPopDec(i,:) = Problem.lower + rand(1,Problem.D) .* (Problem.upper-Problem.lower);
            else
                newPopDec(i,:) = Population(i).dec;
            end
        end
    end
    Population = Problem.Evaluation(newPopDec);
    Ct_1 = Ct;
end