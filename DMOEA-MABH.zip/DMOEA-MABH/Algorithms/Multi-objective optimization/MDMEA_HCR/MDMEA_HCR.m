classdef MDMEA_HCR < ALGORITHM
%<multi/many> <real> <none> <dynamic>
% Dynamic Multiobjective Optimization algorithm
% nr    ---   2 --- Maximum number of solutions replaced by each offspring

% This is a simple demo of MDMEA-HCR
%--------------------------------------------------------------------------------------------------------
% If you find this code useful in your work, please cite the following paper " Hu Peng, Changrong Mei, 
% Sixiang Zhang, Zhongtian Luo, Qingfu Zhang, Zhijian Wu. Multi-strategy dynamic multi-objective evolutionary
% algorithm with hybrid environmental change responses. Swarm and Evolutionary Computation, 2023".
%--------------------------------------------------------------------------------------------------------
% This function is implmented by Changrong Mei
%--------------------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------------------
% More information can visit Hu Peng's homepage: https://whuph.github.io/index.html
%--------------------------------------------------------------------------------------------------------
%------------------------------- DMO --------------------------------------------------------------------
    methods
        function main(Algorithm,Problem)
            Problem.iter = 1;
%% Parameter Settings
            %nr = Global.ParameterSet(2);
            type = Algorithm.ParameterSet(2);
            T_min=5;T_max=40; Mid_num=floor(Problem.taut/2); r=1;flexible=4;
            Memory_Set=[];K=0; t_size=20;M_num=5; t = 1;
            dif=0;
            AllPop = [];
            %% Generate the weight vectors
            if Problem.M==2
                  [W,~] = UniformPoint(Problem.N-8,Problem.M);
                  W=Update_Weight(W,Problem.N);
            else
                  [W,~] = UniformPoint(Problem.N,Problem.M);
                   W=Update_Weight(W,Problem.N);
            end   
            
            %% Detect the neighbours of each solution
             B = pdist2(W,W);
             [~,B] = sort(B,2);
             
            %% Generate random population
             Population = Problem.Initialization();
             Z = min(Population.objs,[],1);
            %% Evolutionary optimization
            while Algorithm.NotTerminated(Population)  
                % Tag1 is the mark variable of function evaluation times before each environmental change.
                  Tag1=Problem.FE; 
                % Detecting changes in the environment using re-evaluation methods
                  if Changed(Problem,Population)
                      AllPop = [AllPop,Population];
                      %Population.adds
                       dif=0;
                       % Memory storage strategy
                       [Memory_Set,K]=Memory_store(Population,Memory_Set,t_size,M_num,K);      
                      if Problem.iter==Problem.taut 
                              % The first environmental change occurs, no response is made, and the population is re-evaluated.
                              Last_C=mean(Population.decs,1);
                              Population=Problem.Evaluation(Population.decs);
                      elseif Problem.iter>Problem.taut  
                             % Hybrid environmental change response mechanism
                             Curr_C=mean(Population.decs,1);
                             % Response strategy1: Modified Linear prediction model
                             [New_Pop1,~]=Response_Strategy1(Problem,Population,Problem.N,Problem.D,Last_C,Curr_C,Problem.lower,Problem.upper);
                             % Response strategy2: Memory solution introduction strategy
                             [New_Pop2,~]=Response_Strategy2(Problem,Memory_Set,Problem.N,Problem.D,Problem.lower,Problem.upper);
                             % Response strategy3: Gaussian polynomial mixed mutation strategy
                             [New_Pop3,~]=Response_Strategy3(Problem,Population,Problem.N,Problem.D,Problem.lower,Problem.upper);
                             randNum = randi(100,1,100);
                             randNum2 = randi(50,1,50);
%                              New_Pop1 = New_Pop1(randNum(1:34));
%                              New_Pop2 = New_Pop2(randNum(1:33));
%                              New_Pop3 = New_Pop3(randNum2(1:33)); 

                             % Environmental selection mechanism that select out initial response population
                             Population=EnvironmentalSelection([New_Pop1,New_Pop2,New_Pop3],Problem.N);
                             Last_C=Curr_C; 
                      end
                              r=1;
                             % Response adjustment mechanism(Individual transfer adjustment and  Vector matching adjustment)
                             Population=Response_adjust(Problem,Population,W,Problem.N,Problem.lower,Problem.upper);
                             % Update the ideal point
                             Z=min(Population.objs,[],1);
                  end
                  %else
                       % Tag2 is the mark variable of function evaluation times after each environmental change.
                       Tag2=Problem.FE;
                       if(Tag2-Tag1>100)
                           dif=Tag2-Tag1-100;
                       end
             
                      if Problem.iter-50>=Problem.taut 
                            T=T_min+ceil((T_max-T_min)/(exp(-flexible*(r-Mid_num)/Mid_num)+1)); 
                            B1 = B(:,1:T);
                      else
                            T=20; 
                            B1 = B(:,1:T);
                      end   
                      
                    % Static multi-objective optimization
                    %Population.adds
                    for i = 1 : Problem.N
                        if(dif>0)
                            dif=dif-1; continue;
                        end
                        P = B1(i,randperm(end));
                        % Multi-Strategy evolutionary operators based on variable domains
                        if   T<=T_min+floor((T_max-T_min)/2)
                                           Offspring =OperatorDE(Problem,Population(i),Population(P(1)),Population(P(2)),{1,0.4,1,20});
                        else
                              if rand<0.4
                                           Offspring=OperatorGAhalf(Problem,[Population(i) Population(P(1))]);
                              else
                                           Offspring=DE_current_to_lbest(Problem,Population,Population(i),W,Z,P,Problem.lower,Problem.upper);
                              end
                        end
                        
                        % Update the ideal point
                    Z = min(Z,Offspring.obj);
                        % Update the solutions in P by Tchebycheff approach
                        g_old = max(abs(Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
                        g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
                        update_index=P(find(g_old>=g_new,type));
                        Population(update_index) = Offspring;
                    end
                  %end
                for ii = 1 : length(Population)
                    Population(ii).iter = t;
                end
                if Problem.iter >= Problem.maxIter - 1
                    Population = [AllPop,Population];
                    %[~,rank]   = sort(Population.adds(zeros(length(Population),1)));
                    %Population = Population(rank);
                end
                r = r+1;
                t = t+1;
                Problem.iter = t;
            end
        end
    end
end