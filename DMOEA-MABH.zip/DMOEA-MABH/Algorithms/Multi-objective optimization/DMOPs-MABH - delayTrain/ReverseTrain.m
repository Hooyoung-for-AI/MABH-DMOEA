function [historyReward,numPlays] = ReverseTrain(Problem,Population,historyReward,numPlays,armRecord)
    [FrontNo,~] = NDSort(Population.objs,length(Population));
    TmpReward = FrontNo==ones(1,Problem.N);
    for i = 1 : Problem.N
        reward = TmpReward(i);
        %reward = reward * (1-i./LtrainGroup);
        historyReward(armRecord(i)) = historyReward(armRecord(i)) + 0.3*(reward-historyReward(armRecord(i)));
        %numPlays(armRecord(i)) = numPlays(armRecord(i)) + 1;
    end
end

