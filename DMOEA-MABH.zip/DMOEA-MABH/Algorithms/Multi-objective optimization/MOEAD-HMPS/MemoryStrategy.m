function [D,C] = MemoryStrategy(Population,D,C,archiveSize,flag,index,F)
    sizeD = size(D,1);
    if flag == 0 &&  sizeD < archiveSize
        D = [D;F];
        C = [C;mean(Population.decs,1)];
    elseif flag == 0 && sizeD == archiveSize
        D(1,:) = [];
        D = [D;F];
        C(1,:) = [];
        C = [C;mean(Population.decs,1)];
    else
        D(index,:) = F;
        C(index,:) = mean(Population.decs,1);
    end
end